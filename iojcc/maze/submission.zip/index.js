S="\40\n";M="map";i=991;for(z
=       [                   ]
;   i   ;   )z[--i]=i%30?   8
:   S   [           1   ]   ;
F=d=>   [30,1,-30   ,   -   1
]       [           M   ]   (
(   f,g,h   )=>S[0]<z   [   f
=   d                   +   2
*   h[3&g+i]]&&(z[f]=z[(d   +
f   )       /               2
]   =   S   [   0],i--,F(   f
)       )       )           ,
F(32);console.log(z+='aem1k')